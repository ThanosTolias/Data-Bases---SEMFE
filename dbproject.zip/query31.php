<!DOCTYPE html>
<html lang = "en">                    
                    
<body>                    
                    
    <div class="container">
        <div class="row" id="row">
            <div class="col-md-12">
                <div class="card" id="card-container">
                    <div class="card-body" id="card">

                    <?php
                        include 'db_connection.php';
                        $conn = OpenCon();

                        //$user_year = 2023;
                        //$user_month = 12;
                        //$user_day = 16;
                        //$less_than_duration = 40;
                        //$more_than_duration = 20;
                        //$executive = "Philip Stewart";
                        

                        //$user_date = $user_year . "-" . $user_month . "-" . $user_day; // san na leme energa projects
                        $user_date = $_GET['date1'];
                        $less_than_duration = $_GET['duration11'];
                        $more_than_duration = $_GET['duration1'];
                        $executive = $_GET['name1'];

                        if (empty($user_date) and empty($more_than_duration) and empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project";
                            }
                            else{
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project WHERE datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (!empty($user_date) and empty($more_than_duration) and empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.start_date, '$user_date') <=0 AND datediff(project.end_date, '$user_date') >= 0";
                            }
                            else{
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.start_date, '$user_date') <=0 AND datediff(project.end_date, '$user_date') >= 0
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (empty($user_date) and !empty($more_than_duration) and empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.end_date, project.start_date) >= 30*'$more_than_duration'";
                            }
                            else{
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.end_date, project.start_date) >= 30*'$more_than_duration'
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (empty($user_date) and empty($more_than_duration) and !empty($executive)){
                            if(empty($less_than_duration)){
                            $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                        FROM project p
                                        INNER JOIN executive e
                                        ON e.executive_id = p.executive_id
                                        WHERE e.name_ex = '$executive'";
                            }
                            else{
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (!empty($user_date) and !empty($more_than_duration) and empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.start_date, '$user_date') <=0 AND datediff(project.end_date, '$user_date') >= 0
                                            AND datediff(project.end_date, project.start_date) >= 30*'$more_than_duration'";
                            }
                            else{
                                $query = "SELECT project_id, title, start_date, end_date, abstract, funds FROM project
                                            WHERE datediff(project.start_date, '$user_date') <=0 AND datediff(project.end_date, '$user_date') >= 0
                                            AND datediff(project.end_date, project.start_date) >= 30*'$more_than_duration'
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (!empty($user_date) and empty($more_than_duration) and !empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(p.start_date, '$user_date') <=0 AND datediff(p.end_date, '$user_date') >= 0";
                            }
                            else{
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(p.start_date, '$user_date') <=0 AND datediff(p.end_date, '$user_date') >= 0
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (empty($user_date) and !empty($more_than_duration) and !empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(p.end_date, p.start_date) >= 30*'$more_than_duration'";
                            }
                            else{
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                FROM project p
                                INNER JOIN executive e
                                ON e.executive_id = p.executive_id
                                WHERE e.name_ex = '$executive'
                                AND datediff(p.end_date, p.start_date) >= 30*'$more_than_duration'
                                AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }
                        elseif (!empty($user_date) and !empty($more_than_duration) and !empty($executive)){
                            if(empty($less_than_duration)){
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(p.end_date, p.start_date) >= 30*'$more_than_duration'
                                            AND datediff(p.start_date, '$user_date') <=0 AND datediff(p.end_date, '$user_date') >= 0";
                            }
                            else{
                                $query = "SELECT p.project_id, p.title, p.start_date, p.end_date, p.abstract, p.funds 
                                            FROM project p
                                            INNER JOIN executive e
                                            ON e.executive_id = p.executive_id
                                            WHERE e.name_ex = '$executive'
                                            AND datediff(p.end_date, p.start_date) >= 30*'$more_than_duration'
                                            AND datediff(p.start_date, '$user_date') <=0 AND datediff(p.end_date, '$user_date') >= 0
                                            AND datediff(end_date, start_date) <= '$less_than_duration' * 30";
                            }
                        }

                        $result = mysqli_query($conn, $query);
                        
                        if(mysqli_num_rows($result) == 0){
                            echo '<h1 style="margin-top: 5rem;">No Projects Found!</h1>';
                        }
                        else{

                            echo '<div class="table-responsive">';
                                echo '<table class="table">';
                                    echo '<thead>';
                                        echo '<tr>';
                                            echo '<th>Project_ID</th>';
                                            echo '<th>Title</th>';
                                            echo '<th>Start Date</th>';
                                            echo '<th>End Date</th>';
                                            echo '<th>Abstract</th>';
                                            echo '<th>Funds (Euro)</th>';
                                        echo '</tr>';
                                    echo '</thead>';
                                    echo '<tbody>';
                                    while($row = mysqli_fetch_row($result)){
                                        echo '<tr>';
                                            echo '<td>' . $row[0] . '</td>';
                                            echo '<td>' . $row[1] . '</td>';
                                            echo '<td>' . $row[2] . '</td>';
                                            echo '<td>' . $row[3] . '</td>';
                                            echo '<td>' . $row[4] . '</td>';
                                            echo '<td>' . $row[5] . '</td>';

                                            echo '<td>';
                                                echo '<a type="button" href="./show_researchers_of_project.php?id=' . $row[0]. '">';
                                                echo 'show researchers';
                                                echo '</a>';
                                            echo '</td>';
                                            
                                            echo '<td>';
                                                echo '<a type="button" href="./delete_project.php?id=' . $row[0]. '">';
                                                echo 'delete project';
                                                echo '</a>';
                                            echo '</td>';
                                            

                                        echo '</tr>';
                                    }
                                    echo '</tbody>';
                                echo '</table>';
                            echo '</div>';
                        }
                    ?>
                    </div>
                <a action></a>
                </div>
            </div>
        </div>
    </div>

</body>

</html>